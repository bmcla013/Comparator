/**
 * (Use Javadoc tags to document your code too.
 *
 * @author 6140973(your Panther Id)
 *  
 *  Title:  Comparable and Comparator interfaces (program's title)
* 
* Semester:         COP3804 - Fall 2018
* Lecturer's Name: Prof Charters (name of your lecturer)
*   Description of Program’s Functionality:
*   creates an ArrayList of Course objects and sorts them by different attributes
* of the objects within, then outputs to the user all attributes
*  
*/ 
package coursedirectory;

import java.util.Comparator;

/**
 *
 * @author Brian
 */
public class CompareFLA implements Comparator<Course> {
    //calls the compareTo method to return an appropriate value based on their relation
    public int compare(Course other, Course other1)
    {
        return other.getFLACourseName().compareTo(other1.getFLACourseName());
    }
}
