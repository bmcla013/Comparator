/**
 * (Use Javadoc tags to document your code too.
 *
 * @author 6140973(your Panther Id)
 *  
 *  Title:  Comparable and Comparator interfaces (program's title)
* 
* Semester:         COP3804 - Fall 2018
* Lecturer's Name: Prof Charters (name of your lecturer)
*   Description of Program’s Functionality:
*   creates an ArrayList of Course objects and sorts them by different attributes
* of the objects within, then outputs to the user all attributes
*  
*/ 
package coursedirectory;

import java.util.Comparator;

/**
 *
 * @author Brian
 */
public class CompareYear implements Comparator<Course> {
    /* 
    returns a negative,positive,and zero value depending on the first object's  
    relation to the second object
    */
    public int compare(Course other, Course other1){
        
        if(other.getYearLevel()==other1.getYearLevel()){
            return 0;
        }
        else if(other.getYearLevel()>other1.getYearLevel()){
            return 1;
        }
        else{
            return -1;
        }
}
}
