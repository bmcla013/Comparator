/**
 * (Use Javadoc tags to document your code too.
 *
 * @author 6140973(your Panther Id)
 *  
 *  Title:  Comparable and Comparator interfaces (program's title)
* 
* Semester:         COP3804 - Fall 2018
* Lecturer's Name: Prof Charters (name of your lecturer)
*   Description of Program’s Functionality:
*   creates an ArrayList of Course objects and sorts them by different attributes
* of the objects within, then outputs to the user all attributes
*  
*/ 
package coursedirectory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
/**
 *
 * @author mtsguest
 */
public class CourseDirectory {
Scanner kb = new Scanner(System.in);
public ArrayList<Course> courseDirectory = new ArrayList<Course>();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CourseDirectory myDirectory = new CourseDirectory();
        myDirectory.createFIUCourses();
        myDirectory.displayMenu();
        
    }
    //gets user info, creates a course object and puts into courseDirectory string
    public void createFIUCourses()
    {
        String answer,name,flaCourse,preReqAns;
        int year,credits;
        ArrayList<String> myPrereq = new ArrayList<String>();
        System.out.println("****Welcome to the FIU Course Directory!****\n");
        do{
            System.out.println("Do you wish to create a course? (Yes/No)");
            answer = kb.next();
        //only proceeds with user yes selection otherwise moves to end of loop 
        if(answer.equalsIgnoreCase("yes")){
            System.out.println("What is the FIU Course Name?");
            name = kb.next();
            System.out.println("What is the Florida Course name?");
            flaCourse = kb.next();
            System.out.println("What is the Year Level?");
            year = kb.nextInt();
            System.out.println("What is the Credit Value?");
            credits = kb.nextInt();
            System.out.println("Do you have any course Prerequisites? (Yes/No)");
            preReqAns = kb.next();
        //loop should there be multiple prerequisites
        while(preReqAns.equalsIgnoreCase("yes")){
            int i = 1;
            System.out.println("Type your prerequisite " + i + ":");
            String req = kb.next();
            myPrereq.add(req);
            System.out.println("Do you have another prerequisite? (Yes/No)");
            preReqAns = kb.next();
            i++;
        }
        Course f = new Course(name, flaCourse,year,credits,myPrereq);
        courseDirectory.add(f);
        }
        }while(!(answer.equalsIgnoreCase("no")));
    }
    /* creates a menu for the user which loops until the user decides to exit
    sorting the courseDirectory array through three methods of compareTo
    */
    public void displayMenu()
    {
        String answer;
        System.out.println("\n****Now to show all courses in the directory!****");
        do{
            System.out.println("\nPlease select a method of display:\n"
                    + "1. Sort courses by FIU course name\n"
                    + "2. Sort courses by Florida course name\n"
                    + "3. Sort courses by year level\n"
                    + "4. Exit");
            answer = kb.next();
        //using user choice, sorts the array using appropriate compareto method
        switch(answer){
            case "1":
                Collections.sort(courseDirectory);
                for(int i = 0; i<courseDirectory.size();i++){
                    System.out.println(courseDirectory.get(i));
                }
                break;
            case "2":
                Collections.sort(courseDirectory,new CompareFLA());
                for(int i = 0; i<courseDirectory.size();i++){
                    System.out.println(courseDirectory.get(i));
                }
                break;
            case "3":
                Collections.sort(courseDirectory,new CompareYear());
                for(int i = 0; i<courseDirectory.size();i++){
                    System.out.println(courseDirectory.get(i));
                }
                break;
        }
        }while(!(answer.equalsIgnoreCase("4")));
        System.out.println("\n****Thank you for using the FIU Course Directory!****");
    }
    
    
    
}
