/**
 * (Use Javadoc tags to document your code too.
 *
 * @author 6140973(your Panther Id)
 *  
 *  Title: Error Handling Example (program's title)
* 
* Semester:         COP3804 - Fall 2018
* Lecturer's Name: Prof Charters (name of your lecturer)
*   Description of Program’s Functionality:
*   Checks various files for errors, catches them and throws them to main, ending
* gracefully
*  
*/ 
package errorhandlingexample;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;
/**
 *
 * @author mtsguest
 */
public class ErrorHandlingExample {

    //Define a global array of Student objects, but don't instantiate it until the getUserInput() method.
    Student[] students;
    /**
     * @param args the command line arguments
     */
    //creates new errorHandling object, catches all exceptions
    public static void main(String[] args) {
       boolean tryAgain = true;
       int menuItemSelected = 0;
       ErrorHandlingExample errorHandle1 = new ErrorHandlingExample();
       while (tryAgain)
       {
           try
           {
               menuItemSelected = errorHandle1.getUserInput();
               errorHandle1.processFile(menuItemSelected);
               errorHandle1.summarizeResults();
               tryAgain = false;
           }
           catch (FileNotFoundException e)
           {
               tryAgain = true;
               System.out.println(e.getMessage());
           }
           catch (InputMismatchException e)
           {
               tryAgain = false;
               System.out.println(e.getMessage());
           }
           catch (BadDataException e)
           {
               tryAgain = false;
               System.out.println(e.getMessage());
           }
           catch (NoSuchElementException e)
           {
               tryAgain = false;
               System.out.println(e.getMessage());
           }
           catch (Exception e)
           {
               tryAgain = false;
               System.out.println(e.getMessage());
           }
           
       }
        
        
        
        
    }
    //creates a loop getting user input between 1-6, loops on any other input
    public int getUserInput() 
    {
        boolean validMenu = false;
        int usersChoice = 0;
        Scanner keyboard = new Scanner(System.in);
        
        while (!validMenu)
        {
            try
            {
                displayMenu();
                usersChoice = keyboard.nextInt();
                if (usersChoice < 1 || usersChoice > 6)
                {
                    System.out.println("Your selection is invalid. Enter  1 - 6.");
                    validMenu = false;
                }
                else
                {
                    validMenu = true;
                }
                               
            }
            catch(InputMismatchException e)
            {
                validMenu = false;
                keyboard.nextLine();
                System.out.println("Incorrect menu selection.");
            }
        }
       
        return usersChoice;
        
    }
    
    
    /*receives userinput from menu choice, creates corresponding file, creates array
    of student objects, throws any exceptions to main
    */
    public void processFile(int usersChoice) throws FileNotFoundException, Exception
    {
        int numRecs;
        String fileName;
        String badData1 = "goodFile.txt";
        String badData2 = "tooFewRecs.txt";
        String badData3 = "tooManyRecs.txt";
        String badData4 = "nonNumericRecCounter.txt";
        String badData5 = "invalidData.txt";
        String badData6 = "xyz.txt";
        int i = 0;
        
        
            
        switch (usersChoice)
        {
            case 1:
                fileName = badData1;
                break;
            case 2:
                fileName = badData2;
                break;
            case 3:
                fileName = badData3;
                break;
            case 4:
                fileName = badData4;
                break;
            case 5:
                fileName = badData5;
                break;
            case 6:
                fileName = badData6;
                break;
            default:
                fileName = badData1;
        }
        
        
       
            
        Scanner myFile = null;
        try
        {
           File aFile = new File(fileName);
           myFile = new Scanner(aFile);
           numRecs = myFile.nextInt();
           students = new Student[numRecs];
           for(i = 0; i<numRecs;i++){
               
               String name = myFile.next();
               double gpa = myFile.nextDouble();
               Student holder = new Student(name,gpa);
               students[i] = holder;
           }
           
           if(myFile.hasNext()==true){
               throw new BadDataException();
           }
        myFile.close();
        }
        catch (FileNotFoundException e)
        {
            
            throw new FileNotFoundException("The file " + fileName + " was not found.");
            
        }
        catch (InputMismatchException e)
        {
               throw new InputMismatchException("Expecting numeric, got non numeric");
               
        }
        catch (BadDataException e)
        {
             //You can report on the bad data, and skip the bad record, so you can process the rest of the records.
            System.out.println("More recs than expected, bad data at position " + i);
            i++;
            
        }
        catch (NoSuchElementException e)
        {
            throw new NoSuchElementException("Too few records, data does not exist");   
        }
        catch (Exception e)
        {
               throw new Exception("Unknown Exception");
        }
        finally
        {
            if(myFile!=null)
            {
                myFile.close();
            }
                
        }
          
    }
        
           
        
        
               
                      
  
    //menu output
    public void displayMenu()
    {
        System.out.println("What type of file do you wish to read?");
        System.out.println("1.  Good File");
        System.out.println("2.  Too few recs in the counter (more recs than anticipated");
        System.out.println("3.  Too many recs in the counter (less recs than anticipated");
        System.out.println("4.  Non-numeric record counter");
        System.out.println("5.  Invalid data in record - ex. GPA non-numeric");
        System.out.println("6.  Invalid file name");
  
    }
    
    // uses student array to calculate and output, highest gpa, lowest gpa, and average gpa
    public void summarizeResults()
    {
        double highestGpa=0,lowestGpa=5,averageGpa=0;
        int highestStudent=0,lowestStudent=0;
        if(!(students[0]==null)){
        highestGpa = students[0].getGpa();
        lowestGpa = students[0].getGpa();
        averageGpa = students[0].getGpa();
        }
        
        for(int i = 1; i<students.length;i++){
            
            if(highestGpa<students[i].getGpa()){
                highestGpa = students[i].getGpa();
                highestStudent = i;
            }
            if(lowestGpa>students[i].getGpa()){
                lowestGpa = students[i].getGpa();
                lowestStudent = i;
            }
            averageGpa += students[i].getGpa();
        }
        averageGpa = averageGpa/students.length;
        System.out.println("a.) The student with the lowest gpa is: " + students[lowestStudent].getLastName()
        + " with a gpa of: " + lowestGpa);
        System.out.println("b.) The student with the highest gpa is: " + students[highestStudent].getLastName()
        + " with a gpa of: " + highestGpa);
        System.out.println("c.) The average of all the students' gpa is: " + averageGpa);
        
    }
    
}
