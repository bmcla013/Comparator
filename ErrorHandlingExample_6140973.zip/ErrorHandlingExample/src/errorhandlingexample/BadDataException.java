/**
 * (Use Javadoc tags to document your code too.
 *
 * @author 6140973(your Panther Id)
 *  
 *  Title: Error Handling Example (program's title)
* 
* Semester:         COP3804 - Fall 2018
* Lecturer's Name: Prof Charters (name of your lecturer)
*   Description of Program’s Functionality:
*   Checks various files for errors, catches them and throws them to main, ending
* gracefully
*  
*/ 
package errorhandlingexample;

/**
 *
 * @author mtsguest
 */
public class BadDataException extends RuntimeException {
    
    public BadDataException()
    {
        super();
    }
    
    public BadDataException(String message)
    {
        super(message);
    }
    
}
