/**
 * (Use Javadoc tags to document your code too.
 *
 * @author 6140973(your Panther Id)
 *  
 *  Title: Error Handling Example (program's title)
* 
* Semester:         COP3804 - Fall 2018
* Lecturer's Name: Prof Charters (name of your lecturer)
*   Description of Program’s Functionality:
*   Checks various files for errors, catches them and throws them to main, ending
* gracefully
*  
*/ 
package errorhandlingexample;

/**
 *
 * @author mtsguest
 */
public class Student {
    
    private String lastName;
    private double gpa;
    
    public Student(String ln, double aGPA)
    {
        lastName = ln;
        gpa = aGPA;
    }

    public String getLastName() {
        return lastName;
    }

    public double getGpa() {
        return gpa;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "Student{" + "lastName=" + lastName + ", gpa=" + gpa + '}';
    }
    
    
    
    
    
}
